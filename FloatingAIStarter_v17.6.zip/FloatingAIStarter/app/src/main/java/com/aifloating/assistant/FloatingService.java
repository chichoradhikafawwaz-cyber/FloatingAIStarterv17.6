package com.aifloating.assistant;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {
    private WindowManager wm; private View panel; private WindowManager.LayoutParams params;
    private int startX, startY; private float touchX, touchY;
    private static final String CHANNEL = "floating_robot";
    @Override public void onCreate() { super.onCreate(); createNotification(); if (Settings.canDrawOverlays(this)) showRobot(); }
    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
    private void createNotification() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Robot floating",NotificationManager.IMPORTANCE_LOW));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this,CHANNEL) : new Notification.Builder(this);
        b.setContentTitle("AI Floating Assistant v17.6").setContentText("Robot belajar aktif")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true);
        startForeground(7,b.build());
    }
    private Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(10); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(133,35,220))); return b;
    }
    private void showRobot() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(10,6,10,6); box.setBackgroundColor(Color.rgb(29,9,48));
        TextView robot = new TextView(this); robot.setText("🤖  AI v17.6"); robot.setTextSize(17); robot.setTextColor(Color.rgb(224,163,255)); robot.setTypeface(null,Typeface.BOLD); robot.setGravity(Gravity.CENTER); box.addView(robot);
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button study=btn("Soal"), chat=btn("ChatGPT"), hide=btn("Sembunyi"); actions.addView(study); actions.addView(chat); actions.addView(hide); box.addView(actions);
        study.setOnClickListener(v -> { Intent a=new Intent(this,MainActivity.class); a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(a); });
        chat.setOnClickListener(v -> {
            Intent i=getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
            if(i==null)i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://chatgpt.com"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        });
        hide.setOnClickListener(v -> { Toast.makeText(this,"Robot disembunyikan. Buka aplikasi untuk mengaktifkannya lagi.",Toast.LENGTH_LONG).show(); stopSelf(); });
        params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START; params.x=30; params.y=180;
        robot.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){startX=params.x;startY=params.y;touchX=e.getRawX();touchY=e.getRawY();return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=startX+(int)(e.getRawX()-touchX);params.y=startY+(int)(e.getRawY()-touchY);wm.updateViewLayout(panel,params);return true;}
            return e.getAction()==MotionEvent.ACTION_UP;
        });
        panel=box; try { wm.addView(panel,params); } catch(Exception e) { stopSelf(); }
    }
    @Override public void onDestroy() { super.onDestroy(); if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){} }
    @Override public IBinder onBind(Intent i) { return null; }
}
