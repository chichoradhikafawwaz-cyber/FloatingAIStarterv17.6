package com.aifloating.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    // DEMO ONLY: key tertanam tidak aman untuk distribusi publik.
    private static final String DEMO_ADMIN_KEY = "NEON-LEARN-2026";
    private static final String PREFS = "access";
    private static final String UNLOCKED = "unlocked";
    private static final int PURPLE = Color.rgb(145, 65, 245);
    private static final int BG = Color.rgb(18, 12, 38);
    private static final int CARD = Color.rgb(35, 29, 61);
    private LinearLayout root;
    private CountDownTimer timer;
    private TextView timerLabel;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (getPreferences(MODE_PRIVATE).getBoolean(UNLOCKED, false)) showHome(); else showKeyScreen();
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        t.setPadding(10, 9, 10, 9); return t;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 6); b.setLayoutParams(lp); return b;
    }
    private void base(String title) {
        ScrollView sc = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 22, 20, 22); root.setBackgroundColor(BG);
        TextView h = text(title, 25); h.setTypeface(null, Typeface.BOLD);
        h.setTextColor(Color.rgb(210, 166, 255)); root.addView(h);
        sc.addView(root); setContentView(sc);
    }
    private void showKeyScreen() {
        base("✦ AI Floating Assistant v17.6");
        root.addView(text("Teman belajar AI • Ungu Neon", 16));
        root.addView(text("Masukkan key demo untuk melanjutkan.", 14));
        EditText key = new EditText(this); key.setSingleLine(true);
        key.setHint("Masukkan key akses"); key.setTextColor(Color.WHITE);
        key.setHintTextColor(0xffb8a6c9); root.addView(key);
        root.addView(text("Demo: NEON-LEARN-2026\nJangan gunakan key tertanam untuk aplikasi publik.", 12));
        Button enter = button("Aktifkan akses"); root.addView(enter);
        enter.setOnClickListener(v -> {
            if (DEMO_ADMIN_KEY.equals(key.getText().toString().trim())) {
                getPreferences(MODE_PRIVATE).edit().putBoolean(UNLOCKED, true).apply(); showHome();
            } else Toast.makeText(this, "Key tidak valid. Hubungi admin.", Toast.LENGTH_LONG).show();
        });
    }
    private void showHome() {
        base("✦ AI Floating Assistant");
        root.addView(text("VERSI 17.6 • TEMAN BELAJAR", 14));
        root.addView(text("Pilih fitur untuk latihan dan memahami soal.", 15));

        Button floatBtn = button("🤖 Aktifkan Robot Floating"); root.addView(floatBtn);
        floatBtn.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                new AlertDialog.Builder(this).setTitle("Izin floating dibutuhkan")
                    .setMessage("Izinkan 'Display over other apps' agar robot bisa tampil di atas aplikasi lain.")
                    .setPositiveButton("Buka Pengaturan", (d,w) -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))))
                    .setNegativeButton("Batal", null).show();
            } else {
                startService(new Intent(this, FloatingService.class));
                Toast.makeText(this, "Robot floating aktif", Toast.LENGTH_SHORT).show();
            }
        });

        addFeature("📘 Analisis Soal Latihan", "Ketik soal latihan dan minta penjelasan langkah demi langkah.", this::askQuestion);
        addFeature("🧠 Penjelasan Lengkap", "AI diminta menjelaskan konsep, langkah, jawaban, dan pengecekan.", this::askDetailedQuestion);
        addFeature("💬 Buka ChatGPT", "Buka aplikasi ChatGPT atau situs resminya.", this::openChatGPT);
        addFeature("⏱️ Timer Latihan 15 Menit", "Mulai atau hentikan timer sesi belajar.", this::showTimer);
        addFeature("🪄 Tips Belajar", "Dapatkan saran belajar singkat.", this::showStudyTips);

        Button lock = button("🔐 Kunci Aplikasi"); root.addView(lock);
        lock.setOnClickListener(v -> {
            getPreferences(MODE_PRIVATE).edit().putBoolean(UNLOCKED, false).apply();
            if (timer != null) timer.cancel();
            showKeyScreen();
        });
        root.addView(text("Gunakan untuk latihan. Periksa kembali jawaban AI karena AI bisa keliru. Fitur ini tidak mengisi tes aktif secara otomatis.", 12));
        root.addView(text("P.S. Developer: @developerciko", 12));
    }

    private void addFeature(String title, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setPadding(8, 8, 8, 8);
        card.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CARD));
        card.setBackgroundColor(CARD);
        TextView t = text(title, 17); t.setTypeface(null, Typeface.BOLD); card.addView(t);
        card.addView(text(subtitle, 13));
        Button b = button("Buka"); card.addView(b); b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 5, 0, 5);
        root.addView(card, lp);
    }

    private void askQuestion() { askQuestionWithPrompt(false); }
    private void askDetailedQuestion() { askQuestionWithPrompt(true); }
    private void askQuestionWithPrompt(boolean detailed) {
        EditText input = new EditText(this);
        input.setHint("Ketik soal latihan di sini...");
        input.setMinLines(3); input.setGravity(Gravity.TOP);
        new AlertDialog.Builder(this).setTitle(detailed ? "Penjelasan lengkap" : "Analisis soal latihan").setView(input)
            .setPositiveButton("Lanjutkan ke AI", (d,w) -> {
                String q = input.getText().toString().trim();
                if (q.isEmpty()) { Toast.makeText(this, "Masukkan soal dulu", Toast.LENGTH_SHORT).show(); return; }
                String prompt = detailed
                    ? "Bantu saya belajar untuk latihan. Jelaskan konsep yang diuji, langkah pengerjaan secara runtut dalam bahasa Indonesia, jawaban, dan cek ulang. Jika informasi kurang, tanyakan. Soal latihan: " + q
                    : "Bantu saya belajar. Analisis soal latihan berikut, jelaskan langkah pengerjaan dengan bahasa Indonesia, lalu berikan jawaban dan cek ulang. Jika informasi kurang, tanyakan. Soal: " + q;
                Intent share = new Intent(Intent.ACTION_SEND); share.setType("text/plain"); share.putExtra(Intent.EXTRA_TEXT, prompt);
                try { startActivity(Intent.createChooser(share, "Kirim soal ke ChatGPT atau aplikasi AI")); }
                catch (Exception e) { openChatGPT(); }
            }).setNegativeButton("Batal", null).show();
    }

    private void showTimer() {
        if (timer != null) timer.cancel();
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20, 10, 20, 10);
        timerLabel = new TextView(this); timerLabel.setText("15:00"); timerLabel.setTextSize(30); timerLabel.setGravity(Gravity.CENTER); box.addView(timerLabel);
        new AlertDialog.Builder(this).setTitle("Timer latihan 15 menit").setView(box)
            .setPositiveButton("Mulai", (d,w) -> {
                timer = new CountDownTimer(15 * 60 * 1000L, 1000L) {
                    public void onTick(long millis) {
                        if (timerLabel != null) timerLabel.setText(String.format(java.util.Locale.getDefault(), "%02d:%02d", millis/60000, (millis/1000)%60));
                    }
                    public void onFinish() {
                        if (timerLabel != null) timerLabel.setText("Waktu selesai!");
                        Toast.makeText(MainActivity.this, "Sesi latihan 15 menit selesai.", Toast.LENGTH_LONG).show();
                    }
                }.start();
                Toast.makeText(this, "Timer latihan dimulai", Toast.LENGTH_SHORT).show();
            }).setNegativeButton("Tutup", (d,w) -> { if (timer != null) timer.cancel(); }).show();
    }

    private void showStudyTips() {
        new AlertDialog.Builder(this).setTitle("Tips belajar")
            .setMessage("1. Baca soal sampai selesai.\\n2. Tandai informasi penting.\\n3. Coba kerjakan sendiri terlebih dahulu.\\n4. Minta AI menjelaskan bagian yang belum dipahami.\\n5. Periksa ulang hasilnya.")
            .setPositiveButton("Oke", null).show();
    }

    private void openChatGPT() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
            if (i != null) startActivity(i);
            else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com")));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com")));
        }
    }

    @Override protected void onDestroy() {
        if (timer != null) timer.cancel();
        super.onDestroy();
    }
}
