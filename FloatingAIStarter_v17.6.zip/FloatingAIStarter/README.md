# FloatingAIStarter v17.6

Versi ini menambahkan menu belajar, analisis soal latihan, penjelasan lengkap, timer latihan 15 menit, tips belajar, dan panel floating yang diperbarui.

## Build
Upload ZIP ini ke repositori GitHub sesuai nama file workflow yang dipakai, lalu jalankan GitHub Actions.

## Catatan
- Fitur analisis soal menyiapkan prompt dan membagikannya ke ChatGPT/aplikasi AI yang dipilih; ini bukan integrasi API AI langsung.
- Timer 15 menit berlaku saat layar timer dibuka.
- Kode akses demo `NEON-LEARN-2026` tertanam di aplikasi dan tidak aman untuk distribusi publik. Untuk rilis sungguhan, gunakan validasi server.
- Aplikasi ditujukan untuk belajar dan latihan. Tidak ada fitur untuk mengisi ujian aktif secara otomatis atau menghindari pengawasan.
- Versi 17.6 belum diuji build di lingkungan ini; jalankan GitHub Actions dan periksa log bila gagal.
- Kredit: @developerciko
